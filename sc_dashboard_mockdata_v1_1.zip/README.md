# Supply Chain Dashboard Mock Data (v1.1)

This folder contains synthetic data used to build a 3-tab supply chain dashboard:
1) Overall shipping view
2) Item/shipment tree view
3) Aggregated supply chain + what-if scenarios

Key parameters for this dataset:
- Vehicles: 300 ships, 100 flights, 500 trucks
- Shipments: 1500 (each includes an ETA forecast time series)
- News: 250 articles, multilingual (en/es/zh)
- Refresh intervals (suggested): vehicles 60s, news 180s

## Location
Place this folder at repo root:
- `mock-data/v1/...`

## Notes
All records are synthetic for demo purposes.
