# FAQ

## Why do vehicles not perfectly match shipments?
Mock data uses simplified assignment logic. In real deployments, you would join shipments to vehicle telemetry via TMS/IoT identifiers.

## Can I author scenarios?
Yes. In v1, scenario authoring is client-side and applies a simple rule-based simulation.

## Why are some news items in Spanish/Chinese?
To exercise multilingual rendering. In v2, RSS feeds may include multilingual content, and translation can be added.
